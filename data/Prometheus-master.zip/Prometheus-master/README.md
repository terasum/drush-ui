# Prometheus
### [1 Node Exporter for Prometheus Dashboard 20200627](https://github.com/starsliao/Prometheus/tree/master/node_exporter)
### [2 Blackbox Exporter 0.14 for Prometheus Dashboard](https://github.com/starsliao/Prometheus/tree/master/blackbox_exporter)
### [3 wmi_exporter 0.7.0+ for Prometheus Dashboard（windows）](https://github.com/starsliao/Prometheus/tree/master/wmi_exporter)

#### 请进入相应目录查看说明与截图

##### 关注公众号【**全栈运维开发 Python & Vue**】获取更多...
![](https://github.com/starsliao/Prometheus/blob/master/qr.jpg)
