## wmi_exporter 0.7.0+ for Prometheus 监控展示看板（windows监控）
>帮朋友做的Windows的Prometheus监控看板展示，使用wmi_exporter 0.7.0+，需要的同学可以试试。 记得先看下grafana看板的变量设置。

https://grafana.com/grafana/dashboards/10467

>exporter：https://github.com/martinlindhe/wmi_exporter/releases

![](https://github.com/starsliao/Prometheus/raw/master/wmi_exporter/wmi_exporter.png)
