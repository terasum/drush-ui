### Support Grafana v6.7.X/v7.0.X + node_exporter 1.0.1
### The dashboard is quite practical, to optimize the main metrics for display, and supporting Node Exporter v0.16 and above.Includes: CPU,memory,disk I/O, network traffic, temperature and other monitoring metrics.

### 中文版：[https://grafana.com/grafana/dashboards/8919](https://grafana.com/grafana/dashboards/8919)
### English Version：[https://grafana.com/grafana/dashboards/11074](https://grafana.com/grafana/dashboards/11074)

##### 截图
![](https://github.com/starsliao/Prometheus/blob/master/node_exporter/sa.png)
![](https://github.com/starsliao/Prometheus/blob/master/node_exporter/s1.png)
##### 关注公众号【**全栈运维开发 Python & Vue**】获取更多...
![](https://github.com/starsliao/Prometheus/blob/master/qr.jpg)
