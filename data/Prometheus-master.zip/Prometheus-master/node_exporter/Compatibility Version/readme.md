### Compatibility Release Notes:
If you import the latest dashboard, you get an error:
```
Failed create dashboard model
Cannot read property 'Symbol(Symbol.iterator)' of undefined
```
Note that your grafana version is too low, does not support the new BAR GAUGE chart, it is **recommended** to upgrade to **the latest version of grafana**, or re-import version without BAR GAUGE:

[中文版：https://grafana.com/grafana/dashboards/11174](https://grafana.com/grafana/dashboards/11174)

[English Version：https://grafana.com/grafana/dashboards/11173](https://grafana.com/grafana/dashboards/11173)
